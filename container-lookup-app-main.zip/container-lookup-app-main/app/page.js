'use client'

import { useState, useEffect } from 'react'
import { useRouter } from 'next/navigation'
import './globals.css'
import Header from '../components/Header'
import ArrivalAlert from '../components/ArrivalAlert'
import SearchForm from '../components/SearchForm'
import ContainerForm from '../components/ContainerForm'
import ContainerList from '../components/ContainerList'

export default function Home() {
  const [searchType, setSearchType] = useState('container')
  const [searchValue, setSearchValue] = useState('')
  const [results, setResults] = useState([])
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState(null)
  const [savedContainers, setSavedContainers] = useState([])
  const [showSaved, setShowSaved] = useState(false)
  const [arrivalAlerts, setArrivalAlerts] = useState([])
  const [showAlert, setShowAlert] = useState(false)
  const [showAddForm, setShowAddForm] = useState(false)
  const [showAllContainers, setShowAllContainers] = useState(false)
  const [allContainers, setAllContainers] = useState([])
  const [editingContainer, setEditingContainer] = useState(null)
  const [currentTime, setCurrentTime] = useState(new Date())
  const [isAuthChecking, setIsAuthChecking] = useState(true)
  const router = useRouter()

  // Check authentication
  useEffect(() => {
    const isAuthenticated = localStorage.getItem('isAuthenticated')
    if (!isAuthenticated) {
      router.push('/login')
    } else {
      setIsAuthChecking(false)
    }
  }, [router])

  // Load saved containers and check for arrivals on mount
  useEffect(() => {
    if (isAuthChecking) return

    loadSavedContainers()
    checkArrivals()
    // Check for arrivals every minute
    const interval = setInterval(checkArrivals, 60000)
    // Update current time every second for countdown/countup
    const timeInterval = setInterval(() => setCurrentTime(new Date()), 1000)
    return () => {
      clearInterval(interval)
      clearInterval(timeInterval)
    }
  }, [])

  const loadSavedContainers = () => {
    try {
      const saved = localStorage.getItem('savedContainers')
      if (saved) {
        const containers = JSON.parse(saved)
        // Sort by endDate ascending (oldest/arrived first)
        containers.sort((a, b) => new Date(a.endDate) - new Date(b.endDate))
        setSavedContainers(containers)
      }
    } catch (err) {
      console.error('Error loading saved containers:', err)
    }
  }

  const saveContainer = (container) => {
    try {
      const saved = localStorage.getItem('savedContainers')
      let containers = saved ? JSON.parse(saved) : []

      // Check if already saved
      const exists = containers.some(c =>
        String(c.containerNumber) === String(container.containerNumber) &&
        String(c.billOfLading) === String(container.billOfLading)
      )

      if (exists) {
        setError('Container is already saved')
        setTimeout(() => setError(null), 3000)
        return
      }

      // Add saved date
      const containerToSave = {
        ...container,
        savedAt: new Date().toISOString()
      }

      containers.push(containerToSave)
      // Sort by endDate ascending
      containers.sort((a, b) => new Date(a.endDate) - new Date(b.endDate))
      localStorage.setItem('savedContainers', JSON.stringify(containers))
      setSavedContainers(containers)

      // Show success message
      const successMsg = `Container ${container.containerNumber} saved!`
      setError(null)
      alert(successMsg)
    } catch (err) {
      console.error('Error saving container:', err)
      setError('Failed to save container')
    }
  }

  const removeSavedContainer = (containerNumber, billOfLading) => {
    try {
      const saved = localStorage.getItem('savedContainers')
      if (!saved) return

      let containers = JSON.parse(saved)
      containers = containers.filter(c =>
        !(String(c.containerNumber) === String(containerNumber) && String(c.billOfLading) === String(billOfLading))
      )

      localStorage.setItem('savedContainers', JSON.stringify(containers))
      setSavedContainers(containers)
    } catch (err) {
      console.error('Error removing container:', err)
    }
  }

  const isContainerSaved = (containerNumber, billOfLading) => {
    return savedContainers.some(c =>
      String(c.containerNumber) === String(containerNumber) &&
      String(c.billOfLading) === String(billOfLading)
    )
  }

  const checkArrivals = () => {
    try {
      const saved = localStorage.getItem('savedContainers')
      if (!saved) return

      const containers = JSON.parse(saved)
      const today = new Date()
      today.setHours(0, 0, 0, 0)

      const arrived = containers.filter(container => {
        const endDate = new Date(container.endDate)
        endDate.setHours(0, 0, 0, 0)
        return endDate <= today
      })

      if (arrived.length > 0) {
        setArrivalAlerts(arrived)
        setShowAlert(true)
      } else {
        setArrivalAlerts([])
        setShowAlert(false)
      }
    } catch (err) {
      console.error('Error checking arrivals:', err)
    }
  }

  const handleSearch = async (e) => {
    e.preventDefault()

    if (!searchValue.trim()) {
      setError('Please enter a search value')
      return
    }

    setLoading(true)
    setError(null)
    setResults([])
    setShowSaved(false)
    setShowAllContainers(false)
    setShowAddForm(false)

    try {
      const response = await fetch(`/api/search?type=${searchType}&query=${encodeURIComponent(searchValue.trim())}`)
      const data = await response.json()

      if (!response.ok) {
        throw new Error(data.error || 'Search failed')
      }

      setResults(data.results || [])
    } catch (err) {
      setError(err.message || 'An error occurred while searching')
      setResults([])
    } finally {
      setLoading(false)
    }
  }

  const handleAddContainer = async (formData) => {
    setLoading(true)
    setError(null)

    try {
      const response = await fetch('/api/containers', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          ...formData,
          totalAmount: formData.totalAmount ? parseFloat(formData.totalAmount) : 0
        })
      })

      const data = await response.json()

      if (!response.ok) {
        throw new Error(data.error || 'Failed to create container')
      }

      setShowAddForm(false)
      alert('Container added successfully!')

      // Refresh all containers if viewing
      if (showAllContainers) {
        fetchAllContainers()
      }
    } catch (err) {
      setError(err.message || 'An error occurred while creating container')
    } finally {
      setLoading(false)
    }
  }

  const fetchAllContainers = async () => {
    setLoading(true)
    setError(null)
    setShowAllContainers(true)
    setResults([])
    setShowSaved(false)
    setShowAddForm(false)
    setEditingContainer(null)

    try {
      const response = await fetch('/api/containers')
      const data = await response.json()

      if (!response.ok) {
        throw new Error(data.error || 'Failed to fetch containers')
      }

      const containers = data.containers || []
      // Sort by endDate ascending
      containers.sort((a, b) => new Date(a.endDate) - new Date(b.endDate))
      setAllContainers(containers)
    } catch (err) {
      setError(err.message || 'An error occurred while fetching containers')
      setAllContainers([])
    } finally {
      setLoading(false)
    }
  }

  const handleUpdateContainer = async (containerId, formData) => {
    setLoading(true)
    setError(null)

    try {
      const response = await fetch(`/api/containers/${containerId}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          ...formData,
          totalAmount: formData.totalAmount ? parseFloat(formData.totalAmount) : 0
        })
      })

      const data = await response.json()

      if (!response.ok) {
        throw new Error(data.error || 'Failed to update container')
      }

      setEditingContainer(null)
      await fetchAllContainers()
      alert('Container updated successfully!')
    } catch (err) {
      setError(err.message || 'An error occurred while updating container')
    } finally {
      setLoading(false)
    }
  }

  const handleDeleteContainer = async (containerId) => {
    if (!window.confirm('Are you sure you want to delete this container? This action cannot be undone.')) {
      return
    }

    setLoading(true)
    setError(null)

    try {
      const response = await fetch(`/api/containers/${containerId}`, {
        method: 'DELETE'
      })

      if (!response.ok) {
        const data = await response.json()
        throw new Error(data.error || 'Failed to delete container')
      }

      await fetchAllContainers()
      alert('Container deleted successfully!')
    } catch (err) {
      setError(err.message || 'An error occurred while deleting container')
    } finally {
      setLoading(false)
    }
  }

  if (isAuthChecking) {
    return null // Or a loading spinner
  }

  return (
    <div className="container">
      <Header
        showSaved={showSaved}
        savedCount={savedContainers.length}
        showAddForm={showAddForm}
        onToggleSaved={() => {
          setShowSaved(!showSaved)
          setShowAddForm(false)
          setShowAllContainers(false)
          setResults([])
        }}
        onViewAll={fetchAllContainers}
        onToggleAddForm={() => {
          setShowAddForm(!showAddForm)
          setShowSaved(false)
          setShowAllContainers(false)
          setResults([])
        }}
      />

      {showAlert && (
        <ArrivalAlert
          alerts={arrivalAlerts}
          onClose={() => setShowAlert(false)}
        />
      )}

      <SearchForm
        searchType={searchType}
        searchValue={searchValue}
        loading={loading}
        onSearchTypeChange={(e) => {
          setSearchType(e.target.value)
          setSearchValue('')
          setResults([])
        }}
        onSearchValueChange={(e) => setSearchValue(e.target.value)}
        onSubmit={handleSearch}
      />

      {error && (
        <div className="error-message">
          {error}
        </div>
      )}

      {showAddForm && (
        <ContainerForm
          onSubmit={handleAddContainer}
          onCancel={() => setShowAddForm(false)}
          loading={loading}
        />
      )}

      {showSaved && (
        <ContainerList
          containers={savedContainers}
          loading={false}
          title="💾 Saved Containers"
          subtitle={`${savedContainers.length} saved`}
          emptyMessage="No saved containers yet"
          onRemoveSaved={removeSavedContainer}
          isContainerSaved={isContainerSaved}
          currentTime={currentTime}
        />
      )}

      {showAllContainers && (
        <ContainerList
          containers={allContainers}
          loading={loading}
          title="📋 All Containers in Database"
          subtitle={`${allContainers.length} ${allContainers.length === 1 ? 'container' : 'containers'} total`}
          emptyMessage="No containers in database"
          onEdit={(container) => setEditingContainer(container.id)}
          onDelete={handleDeleteContainer}
          onSave={saveContainer}
          onRemoveSaved={removeSavedContainer}
          isContainerSaved={isContainerSaved}
          currentTime={currentTime}
          editingContainerId={editingContainer}
          onUpdateContainer={handleUpdateContainer}
          onCancelEdit={() => setEditingContainer(null)}
        />
      )}

      {results.length > 0 && !showSaved && !showAllContainers && (
        <ContainerList
          containers={results}
          loading={loading}
          title="🔍 Search Results"
          subtitle={`Found ${results.length} ${results.length === 1 ? 'match' : 'matches'}`}
          onSave={saveContainer}
          onRemoveSaved={removeSavedContainer}
          isContainerSaved={isContainerSaved}
          currentTime={currentTime}
        />
      )}
    </div>
  )
}
