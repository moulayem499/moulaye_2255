import './globals.css'

export const metadata = {
  title: 'Container Lookup',
  description: 'Search for container information by Container Number or Bill of Lading',
}

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  )
}

