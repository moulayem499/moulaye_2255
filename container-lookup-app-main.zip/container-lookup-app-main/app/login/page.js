'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import '../globals.css'

export default function LoginPage() {
    const [username, setUsername] = useState('')
    const [password, setPassword] = useState('')
    const [error, setError] = useState('')
    const [loading, setLoading] = useState(false)
    const router = useRouter()

    const handleLogin = async (e) => {
        e.preventDefault()
        setError('')
        setLoading(true)

        // Simulate API call
        await new Promise(resolve => setTimeout(resolve, 1000))

        // Simple hardcoded check
        if (username === 'admin' && password === 'admin123') {
            localStorage.setItem('isAuthenticated', 'true')
            router.push('/')
        } else {
            setError('Invalid username or password')
            setLoading(false)
        }
    }

    return (
        <div className="login-container">
            <div className="login-card">
                <div className="login-header">
                    <div className="logo-icon large">🚢</div>
                    <h1>Welcome Back</h1>
                    <p>Logistics Management System</p>
                </div>

                <form onSubmit={handleLogin} className="login-form">
                    <div className="form-group">
                        <label htmlFor="username">Username</label>
                        <input
                            type="text"
                            id="username"
                            value={username}
                            onChange={(e) => setUsername(e.target.value)}
                            placeholder="Enter your username"
                            required
                        />
                    </div>

                    <div className="form-group">
                        <label htmlFor="password">Password</label>
                        <input
                            type="password"
                            id="password"
                            value={password}
                            onChange={(e) => setPassword(e.target.value)}
                            placeholder="Enter your password"
                            required
                        />
                    </div>

                    {error && <div className="error-message">{error}</div>}

                    <button type="submit" className="login-btn" disabled={loading}>
                        {loading ? 'Signing in...' : 'Sign In'}
                    </button>
                </form>
            </div>

            <style jsx>{`
        .login-container {
          min-height: 100vh;
          display: flex;
          align-items: center;
          justify-content: center;
          background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
          padding: 20px;
        }

        .login-card {
          background: white;
          padding: 40px;
          border-radius: 16px;
          box-shadow: 0 10px 25px rgba(0, 0, 0, 0.1);
          width: 100%;
          max-width: 400px;
        }

        .login-header {
          text-align: center;
          margin-bottom: 30px;
        }

        .logo-icon.large {
          font-size: 48px;
          margin-bottom: 16px;
        }

        h1 {
          color: #1a1a1a;
          margin: 0 0 8px 0;
          font-size: 24px;
        }

        p {
          color: #666;
          margin: 0;
        }

        .login-form {
          display: flex;
          flex-direction: column;
          gap: 20px;
        }

        .form-group {
          display: flex;
          flex-direction: column;
          gap: 8px;
        }

        label {
          font-weight: 500;
          color: #333;
          font-size: 14px;
        }

        input {
          padding: 12px;
          border: 1px solid #e1e1e1;
          border-radius: 8px;
          font-size: 16px;
          transition: all 0.2s;
        }

        input:focus {
          border-color: #0070f3;
          outline: none;
          box-shadow: 0 0 0 3px rgba(0, 112, 243, 0.1);
        }

        .login-btn {
          background: #0070f3;
          color: white;
          border: none;
          padding: 14px;
          border-radius: 8px;
          font-size: 16px;
          font-weight: 600;
          cursor: pointer;
          transition: background 0.2s;
          margin-top: 10px;
        }

        .login-btn:hover {
          background: #0051a2;
        }

        .login-btn:disabled {
          background: #ccc;
          cursor: not-allowed;
        }

        .error-message {
          background: #fff5f5;
          color: #e53e3e;
          padding: 10px;
          border-radius: 6px;
          font-size: 14px;
          text-align: center;
          border: 1px solid #fed7d7;
        }
      `}</style>
        </div>
    )
}
