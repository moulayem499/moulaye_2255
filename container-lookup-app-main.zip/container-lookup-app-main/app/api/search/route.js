import { searchContainers } from '../../../lib/db'

export const dynamic = 'force-dynamic'

export async function GET(request) {
  try {
    const { searchParams } = new URL(request.url)
    const searchType = searchParams.get('type') || 'container'
    const query = searchParams.get('query') || ''

    if (!query) {
      return Response.json(
        { error: 'Search query is required' },
        { status: 400 }
      )
    }

    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 300))

    // Search containers from database
    const results = searchContainers(searchType, query)

    return Response.json({
      results,
      count: results.length
    })
  } catch (error) {
    return Response.json(
      { error: 'Internal server error', message: error.message },
      { status: 500 }
    )
  }
}

