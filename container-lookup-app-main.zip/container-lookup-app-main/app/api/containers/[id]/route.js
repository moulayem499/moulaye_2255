import { getContainerById, updateContainer, deleteContainer } from '../../../../lib/db'

export async function GET(request, { params }) {
  try {
    const { id } = params
    const container = getContainerById(id)
    
    if (!container) {
      return Response.json(
        { error: 'Container not found' },
        { status: 404 }
      )
    }
    
    return Response.json({ container })
  } catch (error) {
    return Response.json(
      { error: 'Failed to fetch container', message: error.message },
      { status: 500 }
    )
  }
}

export async function PUT(request, { params }) {
  try {
    const { id } = params
    const body = await request.json()
    
    const updated = updateContainer(id, body)
    
    if (!updated) {
      return Response.json(
        { error: 'Container not found' },
        { status: 404 }
      )
    }
    
    return Response.json({ container: updated })
  } catch (error) {
    return Response.json(
      { error: 'Failed to update container', message: error.message },
      { status: 500 }
    )
  }
}

export async function DELETE(request, { params }) {
  try {
    const { id } = params
    const deleted = deleteContainer(id)
    
    if (!deleted) {
      return Response.json(
        { error: 'Container not found' },
        { status: 404 }
      )
    }
    
    return Response.json({ message: 'Container deleted successfully' })
  } catch (error) {
    return Response.json(
      { error: 'Failed to delete container', message: error.message },
      { status: 500 }
    )
  }
}

