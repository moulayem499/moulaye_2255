import { getAllContainers, createContainer } from '../../../lib/db'

export const dynamic = 'force-dynamic'

export async function GET(request) {
  try {
    const containers = getAllContainers()
    return Response.json({ containers, count: containers.length })
  } catch (error) {
    return Response.json(
      { error: 'Failed to fetch containers', message: error.message },
      { status: 500 }
    )
  }
}

export async function POST(request) {
  try {
    const body = await request.json()

    // Validate required fields
    if (!body.containerNumber || !body.billOfLading || !body.supplierName || !body.invoiceNumber) {
      return Response.json(
        { error: 'Missing required fields: containerNumber, billOfLading, supplierName, invoiceNumber' },
        { status: 400 }
      )
    }

    const newContainer = createContainer(body)
    return Response.json({ container: newContainer }, { status: 201 })
  } catch (error) {
    return Response.json(
      { error: 'Failed to create container', message: error.message },
      { status: 500 }
    )
  }
}

