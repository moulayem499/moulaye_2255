import React, { useState, useEffect } from 'react';
import './App.css';
import axios from 'axios';

const API_URL = 'http://localhost:5000/api';

function App() {
  const [data, setData] = useState([]);
  const [columns, setColumns] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [showAddForm, setShowAddForm] = useState(false);
  const [editingItem, setEditingItem] = useState(null);
  const [formData, setFormData] = useState({});
  const [stats, setStats] = useState(null);
  const [filterPending, setFilterPending] = useState(true); // Default to showing pending shipments

  useEffect(() => {
    fetchData();
    fetchStats();
  }, []);

  const fetchData = async () => {
    try {
      setLoading(true);
      setError(null);
      const response = await axios.get(`${API_URL}/data`);
      const fetchedData = response.data.data || [];
      setData(fetchedData);
      if (fetchedData && fetchedData.length > 0) {
        const cols = Object.keys(fetchedData[0]);
        setColumns(cols);
        console.log('Loaded data:', fetchedData.length, 'items with columns:', cols);
      } else {
        setColumns([]);
        console.log('No data loaded');
      }
    } catch (err) {
      const errorMsg = err.response?.data?.error || err.message || 'Failed to fetch data';
      setError(`Failed to fetch data: ${errorMsg}`);
      console.error('Fetch error:', err);
      setData([]);
      setColumns([]);
    } finally {
      setLoading(false);
    }
  };

  const fetchStats = async () => {
    try {
      const response = await axios.get(`${API_URL}/stats`);
      setStats(response.data.stats);
    } catch (err) {
      console.error('Failed to fetch stats:', err);
    }
  };

  const handleFileUpload = async (event) => {
    const file = event.target.files[0];
    if (!file) return;

    const formData = new FormData();
    formData.append('file', file);

    try {
      setLoading(true);
      setError(null);
      const response = await axios.post(`${API_URL}/upload`, formData, {
        headers: {
          'Content-Type': 'multipart/form-data',
        },
      });

      const uploadedData = response.data.data || [];
      const uploadedColumns = response.data.columns || [];
      setData(uploadedData);
      setColumns(uploadedColumns);
      setStats(null);
      await fetchStats();
      console.log('File uploaded:', uploadedData.length, 'items, columns:', uploadedColumns);
      alert(`File uploaded successfully! Loaded ${uploadedData.length} items.`);
    } catch (err) {
      const errorMsg = err.response?.data?.error || err.message || 'Unknown error';
      setError('Failed to upload file: ' + errorMsg);
      console.error('Upload error:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleExport = async () => {
    try {
      setLoading(true);
      const response = await axios.post(`${API_URL}/export`, {}, {
        responseType: 'blob',
      });

      const url = window.URL.createObjectURL(new Blob([response.data]));
      const link = document.createElement('a');
      link.href = url;
      link.setAttribute('download', 'logistics_export.xlsx');
      document.body.appendChild(link);
      link.click();
      link.remove();
    } catch (err) {
      setError('Failed to export file: ' + (err.response?.data?.error || err.message));
    } finally {
      setLoading(false);
    }
  };

  const handleAdd = async () => {
    try {
      setLoading(true);
      await axios.post(`${API_URL}/data`, formData);
      setFormData({});
      setShowAddForm(false);
      await fetchData();
      await fetchStats();
    } catch (err) {
      setError('Failed to add item: ' + (err.response?.data?.error || err.message));
    } finally {
      setLoading(false);
    }
  };

  const handleUpdate = async () => {
    try {
      setLoading(true);
      await axios.put(`${API_URL}/data/${editingItem.id}`, formData);
      setFormData({});
      setEditingItem(null);
      await fetchData();
      await fetchStats();
    } catch (err) {
      setError('Failed to update item: ' + (err.response?.data?.error || err.message));
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (id) => {
    if (!window.confirm('Are you sure you want to delete this item?')) return;

    try {
      setLoading(true);
      await axios.delete(`${API_URL}/data/${id}`);
      await fetchData();
      await fetchStats();
    } catch (err) {
      setError('Failed to delete item: ' + (err.response?.data?.error || err.message));
    } finally {
      setLoading(false);
    }
  };

  const startEdit = (item) => {
    setEditingItem(item);
    setFormData({ ...item });
    setShowAddForm(true);
  };

  const cancelEdit = () => {
    setEditingItem(null);
    setFormData({});
    setShowAddForm(false);
  };

  // Filter function to get pending shipments (not yet arrived)
  const getPendingShipments = (shipments) => {
    if (!shipments || shipments.length === 0) return [];
    
    const today = new Date();
    today.setHours(0, 0, 0, 0); // Reset time to start of day
    
    return shipments.filter(item => {
      // Try different possible field names for EAT
      const eatField = item['EAT'] || item['EAT '] || item['Unnamed: 14'];
      if (!eatField) return false;
      
      try {
        // Parse the date - handle different formats
        let eatDate;
        if (typeof eatField === 'string') {
          // Handle GMT format: "Mon, 21 Apr 2025 00:00:00 GMT"
          if (eatField.includes('GMT') || eatField.includes('UTC')) {
            eatDate = new Date(eatField);
          } else {
            // Try standard ISO format
            eatDate = new Date(eatField);
          }
        } else if (eatField instanceof Date) {
          eatDate = eatField;
        } else {
          return false;
        }
        
        // Check if date is valid
        if (isNaN(eatDate.getTime())) return false;
        
        // Reset time to start of day for comparison
        eatDate.setHours(0, 0, 0, 0);
        
        // Return true if EAT is today or in the future (hasn't arrived yet)
        return eatDate >= today;
      } catch (e) {
        console.warn('Error parsing EAT date:', eatField, e);
        return false;
      }
    });
  };

  // Get filtered data
  const displayData = filterPending ? getPendingShipments(data) : data;

  return (
    <div className="App">
      <div className="container">
        <header className="header">
          <h1>📦 Logistics Management App</h1>
          <p>Manage your logistics data with ease</p>
        </header>

        {error && (
          <div className="error-message">
            {error}
            <button onClick={() => setError(null)}>×</button>
          </div>
        )}

        <div className="toolbar">
          <label className="file-upload-btn">
            📁 Upload Excel File
            <input
              type="file"
              accept=".xlsx,.xls"
              onChange={handleFileUpload}
              style={{ display: 'none' }}
            />
          </label>
          <button 
            onClick={(e) => {
              e.preventDefault();
              handleExport();
            }} 
            disabled={!data || data.length === 0} 
            className="export-btn"
            type="button"
          >
            💾 Export to Excel
          </button>
          <button
            onClick={(e) => {
              e.preventDefault();
              e.stopPropagation();
              console.log('Filter button clicked, current state:', filterPending);
              setFilterPending(!filterPending);
            }}
            className={filterPending ? "filter-btn active" : "filter-btn"}
            disabled={!data || data.length === 0}
            type="button"
          >
            {filterPending ? '📦 Show All' : '⏳ Pending Only'}
          </button>
          <button
            onClick={(e) => {
              e.preventDefault();
              setShowAddForm(true);
              setEditingItem(null);
              setFormData({});
            }}
            className="add-btn"
            type="button"
          >
            ➕ Add New Item
          </button>
        </div>

        {stats && stats.totalItems > 0 && (
          <div className="stats">
            <h3>📊 Statistics</h3>
            <div className="stats-grid">
              <div className="stat-item">
                <span className="stat-label">Total Items:</span>
                <span className="stat-value">{stats.totalItems}</span>
              </div>
              <div className="stat-item">
                <span className="stat-label">Columns:</span>
                <span className="stat-value">{stats.columns?.length || 0}</span>
              </div>
              {data && data.length > 0 && (
                <>
                  <div className="stat-item">
                    <span className="stat-label">Pending Shipments:</span>
                    <span className="stat-value" style={{ color: '#f57c00' }}>
                      {getPendingShipments(data).length}
                    </span>
                  </div>
                  <div className="stat-item">
                    <span className="stat-label">Companies:</span>
                    <span className="stat-value">
                      {new Set(data.map(item => item['Company Name'] || item['Unnamed: 1']).filter(Boolean)).size}
                    </span>
                  </div>
                  <div className="stat-item">
                    <span className="stat-label">Containers:</span>
                    <span className="stat-value">
                      {data.filter(item => item['Container n°'] || item['Container n° '] || item['Unnamed: 13']).length}
                    </span>
                  </div>
                </>
              )}
            </div>
          </div>
        )}
        
        {data && data.length > 0 && (
          <div className="data-summary">
            <h3>📋 Data Summary</h3>
            {filterPending ? (
              <div className="pending-header">
                <h4>⏳ Pending Shipments (Not Yet Arrived)</h4>
                <p>
                  Showing <strong style={{color: '#f57c00', fontSize: '1.2rem'}}>{displayData.length}</strong> pending shipments out of <strong>{data.length}</strong> total
                </p>
              </div>
            ) : (
              <p>
                Showing <strong>{data.length}</strong> logistics entries
              </p>
            )}
            {filterPending && displayData.length === 0 && (
              <p className="no-pending">✅ All shipments have arrived!</p>
            )}
            {columns && columns.length > 0 && (
              <details className="columns-list">
                <summary>View Column Names ({columns.length})</summary>
                <div className="columns-grid">
                  {columns.map((col, idx) => (
                    <span key={idx} className="column-tag">{col}</span>
                  ))}
                </div>
              </details>
            )}
          </div>
        )}

        {showAddForm && (
          <div className="form-modal">
            <div className="form-content">
              <h2>{editingItem ? 'Edit Item' : 'Add New Item'}</h2>
              <div className="form-grid">
                {columns && columns.length > 0 ? (
                  columns.map((col) => (
                    <div key={col} className="form-field">
                      <label>{col}</label>
                      <input
                        type="text"
                        value={formData[col] || ''}
                        onChange={(e) =>
                          setFormData({ ...formData, [col]: e.target.value })
                        }
                        placeholder={`Enter ${col}`}
                      />
                    </div>
                  ))
                ) : (
                  <p>Please upload an Excel file first to see the column structure.</p>
                )}
              </div>
              <div className="form-actions">
                <button
                  onClick={editingItem ? handleUpdate : handleAdd}
                  className="save-btn"
                  disabled={loading}
                >
                  {editingItem ? 'Update' : 'Add'}
                </button>
                <button onClick={cancelEdit} className="cancel-btn">
                  Cancel
                </button>
              </div>
            </div>
          </div>
        )}

        {loading && <div className="loading">Loading...</div>}

        {(!data || data.length === 0) && !loading ? (
          <div className="empty-state">
            <p>📋 No data available. Upload an Excel file to get started!</p>
          </div>
        ) : (
          <div className="table-container">
            {columns && columns.length > 0 ? (
              <table className="data-table">
                <thead>
                  <tr>
                    {columns.map((col) => (
                      <th key={col}>{col}</th>
                    ))}
                    <th>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {displayData.length === 0 && filterPending ? (
                    <tr>
                      <td colSpan={columns.length + 1} className="no-results">
                        ✅ All shipments have arrived! No pending shipments.
                      </td>
                    </tr>
                  ) : (
                    displayData.map((item, index) => (
                    <tr key={index}>
                      {columns.map((col) => (
                        <td key={col}>{item[col]?.toString() || ''}</td>
                      ))}
                      <td className="actions">
                        <button
                          onClick={() => startEdit(item)}
                          className="edit-btn"
                          title="Edit"
                        >
                          ✏️
                        </button>
                        <button
                          onClick={() => handleDelete(item.id || index + 1)}
                          className="delete-btn"
                          title="Delete"
                        >
                          🗑️
                      </button>
                    </td>
                  </tr>
                    ))
                  )}
                </tbody>
              </table>
            ) : (
              <div className="empty-state">
                <p>📋 No columns available. Upload an Excel file to get started!</p>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}

export default App;

