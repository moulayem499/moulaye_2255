import React from 'react';

export default function SearchForm({
    searchType,
    searchValue,
    loading,
    onSearchTypeChange,
    onSearchValueChange,
    onSubmit
}) {
    return (
        <form className="search-form" onSubmit={onSubmit}>
            <div className="form-group">
                <label htmlFor="searchType">Search By</label>
                <select
                    id="searchType"
                    value={searchType}
                    onChange={onSearchTypeChange}
                >
                    <option value="container">Container Number</option>
                    <option value="billOfLading">Bill of Lading</option>
                    <option value="supplier">Supplier Name</option>
                    <option value="invoice">Invoice Number</option>
                </select>
            </div>

            <div className="form-group">
                <label htmlFor="searchValue">
                    {searchType === 'container'
                        ? 'Container Number'
                        : searchType === 'billOfLading'
                            ? 'Bill of Lading'
                            : searchType === 'supplier'
                                ? 'Supplier Name'
                                : 'Invoice Number'}
                </label>
                <input
                    id="searchValue"
                    type="text"
                    value={searchValue}
                    onChange={onSearchValueChange}
                    placeholder={
                        searchType === 'container'
                            ? 'Enter container number (e.g., ABCD1234567)'
                            : searchType === 'billOfLading'
                                ? 'Enter bill of lading number (e.g., BOL001234)'
                                : searchType === 'supplier'
                                    ? 'Enter supplier name (e.g., Global Trading Co.)'
                                    : 'Enter invoice number (e.g., INV-2024-001234)'
                    }
                />
            </div>

            <button
                type="submit"
                className="search-button"
                disabled={loading || !searchValue.trim()}
            >
                {loading ? 'Searching...' : '🔍 Search'}
            </button>
        </form>
    );
}
