import React, { useState, useEffect } from 'react';

export default function ContainerForm({
    initialData = {},
    onSubmit,
    onCancel,
    loading,
    isEditing = false
}) {
    const [formData, setFormData] = useState({
        containerNumber: '',
        billOfLading: '',
        supplierName: '',
        invoiceNumber: '',
        totalAmount: '',
        depositPaid: false,
        balancePaid: false,
        startDate: '',
        startLocation: '',
        endDate: '',
        portDestination: '',
        ...initialData
    });

    // Update form data when initialData changes
    useEffect(() => {
        if (initialData && Object.keys(initialData).length > 0) {
            setFormData(prev => ({ ...prev, ...initialData }));
        }
    }, [initialData]);

    const handleSubmit = (e) => {
        e.preventDefault();
        onSubmit(formData);
    };

    return (
        <div className="add-container-form">
            {isEditing ? <h3>✏️ Edit Container</h3> : <h2>➕ Add New Container</h2>}
            <form onSubmit={handleSubmit}>
                <div className="form-grid">
                    <div className="form-group">
                        <label htmlFor="containerNumber">Container Number *</label>
                        <input
                            id="containerNumber"
                            type="text"
                            value={formData.containerNumber}
                            onChange={(e) => setFormData({ ...formData, containerNumber: e.target.value })}
                            required
                            placeholder="e.g., ABCD1234567"
                        />
                    </div>

                    <div className="form-group">
                        <label htmlFor="billOfLading">Bill of Lading *</label>
                        <input
                            id="billOfLading"
                            type="text"
                            value={formData.billOfLading}
                            onChange={(e) => setFormData({ ...formData, billOfLading: e.target.value })}
                            required
                            placeholder="e.g., BOL001234"
                        />
                    </div>

                    <div className="form-group">
                        <label htmlFor="supplierName">Supplier Name *</label>
                        <input
                            id="supplierName"
                            type="text"
                            value={formData.supplierName}
                            onChange={(e) => setFormData({ ...formData, supplierName: e.target.value })}
                            required
                            placeholder="e.g., Global Trading Co. Ltd."
                        />
                    </div>

                    <div className="form-group">
                        <label htmlFor="invoiceNumber">Invoice Number *</label>
                        <input
                            id="invoiceNumber"
                            type="text"
                            value={formData.invoiceNumber}
                            onChange={(e) => setFormData({ ...formData, invoiceNumber: e.target.value })}
                            required
                            placeholder="e.g., INV-2024-001234"
                        />
                    </div>

                    <div className="form-group">
                        <label htmlFor="totalAmount">Total Amount ($)</label>
                        <input
                            id="totalAmount"
                            type="number"
                            value={formData.totalAmount}
                            onChange={(e) => setFormData({ ...formData, totalAmount: e.target.value })}
                            placeholder="e.g., 50000"
                            min="0"
                            step="0.01"
                        />
                        <small className="form-hint">Deposit (30%) and Balance (70%) will be calculated automatically</small>
                    </div>

                    <div className="form-group">
                        <label htmlFor="startDate">Start Date</label>
                        <input
                            id="startDate"
                            type="date"
                            value={formData.startDate}
                            onChange={(e) => setFormData({ ...formData, startDate: e.target.value })}
                        />
                    </div>

                    <div className="form-group">
                        <label htmlFor="startLocation">Start Location</label>
                        <input
                            id="startLocation"
                            type="text"
                            value={formData.startLocation}
                            onChange={(e) => setFormData({ ...formData, startLocation: e.target.value })}
                            placeholder="e.g., Shanghai, China"
                        />
                    </div>

                    <div className="form-group">
                        <label htmlFor="endDate">End Date</label>
                        <input
                            id="endDate"
                            type="date"
                            value={formData.endDate}
                            onChange={(e) => setFormData({ ...formData, endDate: e.target.value })}
                        />
                    </div>

                    <div className="form-group">
                        <label htmlFor="portDestination">Port Destination</label>
                        <input
                            id="portDestination"
                            type="text"
                            value={formData.portDestination}
                            onChange={(e) => setFormData({ ...formData, portDestination: e.target.value })}
                            placeholder="e.g., Los Angeles, USA"
                        />
                    </div>

                    <div className="form-group checkbox-group">
                        <label className="checkbox-label">
                            <input
                                type="checkbox"
                                checked={formData.depositPaid}
                                onChange={(e) => setFormData({ ...formData, depositPaid: e.target.checked })}
                            />
                            Deposit (30%) Paid
                        </label>
                    </div>

                    <div className="form-group checkbox-group">
                        <label className="checkbox-label">
                            <input
                                type="checkbox"
                                checked={formData.balancePaid}
                                onChange={(e) => setFormData({ ...formData, balancePaid: e.target.checked })}
                            />
                            Balance (70%) Paid
                        </label>
                    </div>
                </div>

                <div className="form-actions">
                    <button type="submit" className="submit-btn" disabled={loading}>
                        {loading ? (isEditing ? 'Updating...' : 'Creating...') : (isEditing ? '💾 Save Changes' : '➕ Add Container')}
                    </button>
                    <button
                        type="button"
                        onClick={onCancel}
                        className="cancel-btn"
                    >
                        Cancel
                    </button>
                </div>
            </form>
        </div>
    );
}
