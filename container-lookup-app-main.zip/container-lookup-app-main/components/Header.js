import React from 'react';
import { useRouter } from 'next/navigation';

export default function Header({
  showSaved,
  savedCount,
  showAddForm,
  onToggleSaved,
  onViewAll,
  onToggleAddForm
}) {
  const router = useRouter()

  const handleLogout = () => {
    localStorage.removeItem('isAuthenticated')
    router.push('/login')
  }

  return (
    <div className="header">
      <div className="logo-container">
        <div className="logo-icon">🚢</div>
        <div className="logo-text">
          <h1>Container Lookup</h1>
          <p className="logo-subtitle">Logistics Management System</p>
        </div>
      </div>
      <p>Search for container information by Container Number or Bill of Lading</p>
      <div className="header-actions">
        <button
          onClick={onToggleSaved}
          className="header-btn saved"
        >
          {showSaved ? '🔍 Search' : '💾 Saved Containers'} ({savedCount})
        </button>
        <button
          onClick={onViewAll}
          className="header-btn view-all"
        >
          📋 View All Containers
        </button>
        <button onClick={onToggleAddForm} className={`header-btn add ${showAddForm ? 'active' : ''}`}>
          {showAddForm ? '❌ Cancel' : '➕ Add Container'}
        </button>
        <button onClick={handleLogout} className="header-btn logout">
          🚪 Logout
        </button>
      </div>

    </div>
  );
}
