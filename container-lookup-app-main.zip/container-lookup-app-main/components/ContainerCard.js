import React, { useState, useEffect } from 'react';

export default function ContainerCard({
    container,
    onEdit,
    onDelete,
    onSave,
    onRemoveSaved,
    isSaved,
    currentTime
}) {
    const [timeStatus, setTimeStatus] = useState(null);

    const endDate = container.endDate ? new Date(container.endDate) : null;
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    if (endDate) endDate.setHours(0, 0, 0, 0);
    const hasArrived = endDate && endDate <= today;

    // Calculate payment details
    const totalAmount = parseFloat(container.totalAmount || 0);
    const depositAmount = totalAmount * 0.3;
    const balanceAmount = totalAmount * 0.7;

    useEffect(() => {
        if (!container.endDate) return;

        const end = new Date(container.endDate);
        end.setHours(0, 0, 0, 0);

        const now = currentTime || new Date();
        const diff = end - now;

        const days = Math.floor(Math.abs(diff) / (1000 * 60 * 60 * 24));

        if (diff > 0) {
            setTimeStatus({
                type: 'countdown',
                text: `Arriving in: ${days} day${days !== 1 ? 's' : ''}`
            });
        } else {
            setTimeStatus({
                type: 'countup',
                text: `Arrived: ${days} day${days !== 1 ? 's' : ''} ago`
            });
        }
    }, [container.endDate, currentTime]);

    return (
        <div className={`result-card ${hasArrived ? 'arrived' : ''}`}>
            <div className="result-header">
                <div className="container-number">
                    {container.containerNumber}
                    {hasArrived && <span className="arrived-badge">ARRIVED</span>}
                </div>
                <div className="bill-of-lading-container">
                    <span className="bill-of-lading">BOL: {container.billOfLading}</span>
                    {timeStatus && (
                        <span className={`timer-badge ${timeStatus.type === 'countdown' ? 'countdown-green' : 'countup-red'}`}>
                            {timeStatus.text}
                        </span>
                    )}
                </div>
            </div>

            <div className="result-details">
                <div className="detail-item supplier-info">
                    <div className="detail-label">Supplier</div>
                    <div className="detail-value">{container.supplierName}</div>
                </div>

                <div className="detail-item invoice-info">
                    <div className="detail-label">Invoice Number</div>
                    <div className="detail-value">{container.invoiceNumber}</div>
                </div>

                <div className="detail-item">
                    <div className="detail-label">Start Date</div>
                    <div className="detail-value">{container.startDate || 'N/A'}</div>
                </div>

                <div className="detail-item">
                    <div className="detail-label">Start Location</div>
                    <div className="detail-value">{container.startLocation || 'N/A'}</div>
                </div>

                <div className={`detail-item arrival-info ${hasArrived ? 'arrived' : ''}`}>
                    <div className="detail-label">End Date (Arrival)</div>
                    <div className="detail-value">{container.endDate || 'N/A'}</div>
                </div>

                <div className="detail-item">
                    <div className="detail-label">Port Destination</div>
                    <div className="detail-value">{container.portDestination || 'N/A'}</div>
                </div>
            </div>

            <div className="payment-section">
                <h4 className="payment-title">💰 Payment Details</h4>
                <div className="payment-details">
                    <div className="payment-summary">
                        <div className="payment-total">
                            <span className="payment-label">Total Amount</span>
                            <span className="payment-amount">${totalAmount.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
                        </div>
                    </div>

                    <div className="payment-breakdown">
                        <div className={`payment-item ${container.depositPaid ? 'paid' : 'pending'}`}>
                            <div className="payment-item-header">
                                <span className="payment-item-label">Deposit (30%)</span>
                                <span className={`payment-status ${container.depositPaid ? 'paid-badge' : 'pending-badge'}`}>
                                    {container.depositPaid ? 'PAID' : 'PENDING'}
                                </span>
                            </div>
                            <div className="payment-item-amount">${depositAmount.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</div>
                        </div>

                        <div className={`payment-item ${container.balancePaid ? 'paid' : 'pending'}`}>
                            <div className="payment-item-header">
                                <span className="payment-item-label">Balance (70%)</span>
                                <span className={`payment-status ${container.balancePaid ? 'paid-badge' : 'pending-badge'}`}>
                                    {container.balancePaid ? 'PAID' : 'PENDING'}
                                </span>
                            </div>
                            <div className="payment-item-amount">${balanceAmount.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</div>
                        </div>
                    </div>
                </div>
            </div>

            <div className="card-actions">
                {isSaved ? (
                    <button
                        onClick={() => onRemoveSaved(container.containerNumber, container.billOfLading)}
                        className="remove-btn"
                    >
                        🗑️ Remove from Saved
                    </button>
                ) : onSave ? (
                    <button
                        onClick={() => onSave(container)}
                        className="save-btn"
                    >
                        💾 Save Container
                    </button>
                ) : null}

                {onEdit && (
                    <button
                        onClick={() => onEdit(container)}
                        className="saved-btn"
                        style={{ flex: 1 }}
                    >
                        ✏️ Edit
                    </button>
                )}

                {onDelete && (
                    <button
                        onClick={() => onDelete(container.id)}
                        className="remove-btn"
                        style={{ flex: 1 }}
                    >
                        🗑️ Delete
                    </button>
                )}
            </div>
        </div>
    );
}
