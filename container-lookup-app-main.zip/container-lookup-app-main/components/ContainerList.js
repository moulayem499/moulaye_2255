import React from 'react';
import ContainerCard from './ContainerCard';
import ContainerForm from './ContainerForm';

export default function ContainerList({
    containers,
    loading,
    title,
    subtitle,
    emptyMessage,
    onEdit,
    onDelete,
    onSave,
    onRemoveSaved,
    isContainerSaved,
    currentTime,
    editingContainerId,
    onUpdateContainer,
    onCancelEdit
}) {
    if (loading) {
        return (
            <div className="loading">
                <p>Loading containers...</p>
            </div>
        );
    }

    if (!containers || containers.length === 0) {
        return (
            <div className="no-results">
                <div className="no-results-icon">📭</div>
                <h3>{emptyMessage || 'No containers found'}</h3>
            </div>
        );
    }

    return (
        <div className="results-container">
            {(title || subtitle) && (
                <div className="results-header">
                    {title && <h2>{title}</h2>}
                    {subtitle && <p className="results-count">{subtitle}</p>}
                </div>
            )}

            <div className="results-list">
                {containers.map((container, index) => {
                    const isEditing = editingContainerId === container.id;

                    if (isEditing) {
                        return (
                            <div key={container.id || index} className="container-form-item">
                                <ContainerForm
                                    initialData={container}
                                    onSubmit={(data) => onUpdateContainer(container.id, data)}
                                    onCancel={onCancelEdit}
                                    isEditing={true}
                                />
                            </div>
                        );
                    }

                    return (
                        <ContainerCard
                            key={container.id || index}
                            container={container}
                            onEdit={onEdit}
                            onDelete={onDelete}
                            onSave={onSave}
                            onRemoveSaved={onRemoveSaved}
                            isSaved={isContainerSaved ? isContainerSaved(container.containerNumber, container.billOfLading) : false}
                            currentTime={currentTime}
                        />
                    );
                })}
            </div>
        </div>
    );
}
