import React from 'react';

export default function ArrivalAlert({ alerts, onClose }) {
    if (!alerts || alerts.length === 0) return null;

    return (
        <div className="arrival-alert">
            <div className="alert-content">
                <div className="alert-icon">🚢</div>
                <div className="alert-text">
                    <strong>Container Arrival Alert!</strong>
                    <p>
                        {alerts.length} {alerts.length === 1 ? 'container has' : 'containers have'} arrived:
                        {alerts.map((c, idx) => (
                            <span key={idx}> {c.containerNumber}{idx < alerts.length - 1 ? ',' : ''}</span>
                        ))}
                    </p>
                </div>
                <button
                    onClick={onClose}
                    className="alert-close"
                >
                    ×
                </button>
            </div>
        </div>
    );
}
